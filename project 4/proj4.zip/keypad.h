/*
 * keypad.h
 *
 * Created: 5/12/2021 11:19:38 PM
 *  Author: jbyon
 */ 


#ifndef KEYPAD_H_
#define KEYPAD_H_

void kp_init();
char kp_isPressed(char r, char c);
char kp_getKey();

enum{
	zero,
	kp1, kp2, kp3, kpA,
	kp4, kp5, kp6, kpB,
	kp7, kp8, kp9, kpC,
	kpStar, kp0, kpOcthrp, kpD
	};

#endif /* KEYPAD_H_ */